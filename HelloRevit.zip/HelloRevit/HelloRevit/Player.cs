﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Form = System.Windows.Forms.Form;

namespace HelloRevit
{
    public partial class Player : Form
    {

        public Quiz quiz;
        public string path = "";
        public string quizpath = "";
        public Player()
        {
            InitializeComponent();
            axWindowsMediaPlayer1.URL = "E:\\人人影视Pro\\摩登家庭第9季\\摩登家庭.Modern.Family.S09E01.中英字幕.WEB.720p-人人影视.mp4";
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }
        public Player(Quiz quiz, string VideoPath)
        {
            InitializeComponent();
            this.quiz = quiz;
            this.path = VideoPath;

            //axWindowsMediaPlayer1.BeginInit();
            //this.Controls.Add(axWindowsMediaPlayer1);
            //axWindowsMediaPlayer1.EndInit();
            axWindowsMediaPlayer1.URL = path;
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }
        public bool isplaying = false;
        private void play(string type)
        {
            bool change = true;
            switch(type)
            {
                case "次梁":
                    break;
                case "楼梯":
                    break;
                case "楼板":
                    break;
                case "柱":
                    break;
                case "内外墙":
                    break;
                default:
                    change = false;
                    TaskDialog.Show("错误", "不存在该课程视频内容");
                    break;
            }

            if(change)
            {
                if(isplaying)
                {
                    axWindowsMediaPlayer1.Ctlcontrols.stop();
                    isplaying = false;
                }
                TaskDialog.Show("123", "修改path");
                path = "E:\\资料\\智慧建造\\视频\\" + type + ".mp4";
                quizpath = "E:\\资料\\智慧建造\\题目\\"+type+".txt";
                axWindowsMediaPlayer1.URL = "E:\\人人影视Pro\\摩登家庭第9季\\摩登家庭.Modern.Family.S09E01.中英字幕.WEB.720p-人人影视.mp4";
                if (!quiz.IsDisposed)
                    quiz.Close();
                quiz = new Quiz(this, quizpath);

                TaskDialog.Show("123", "开始播放");
                try
                {
                    axWindowsMediaPlayer1.Ctlcontrols.play();
                }
                catch(Exception e)
                {
                    TaskDialog.Show("error", e.ToString());
                }
                isplaying = true;
                //quiz.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            play(button1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            play(button2.Text);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            play(button3.Text);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            play(button4.Text);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            play(button5.Text);

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }
    }
}
