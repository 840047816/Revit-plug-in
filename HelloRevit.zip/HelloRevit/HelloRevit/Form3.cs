﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloRevit
{
    public partial class Form3 : Form
    {
        Util util;
        public Form3()
        {
            InitializeComponent();
        }

        public Form3(Util util)
        {
            InitializeComponent();
            this.util = util;
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            //确认
            util.b1 = System.Convert.ToDouble(textBox3.Text);
            util.b2 = System.Convert.ToDouble(textBox4.Text);
            util.c1 = System.Convert.ToDouble(textBox5.Text);
            util.c2 = System.Convert.ToDouble(textBox6.Text);
            util.d1 = System.Convert.ToDouble(textBox7.Text);
            util.d2 = System.Convert.ToDouble(textBox8.Text);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //忽略
            this.Close();

        }
    }
}
