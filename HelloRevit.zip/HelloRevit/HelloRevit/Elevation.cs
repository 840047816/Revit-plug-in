﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;

namespace HelloRevit
{
    class Elevation
    {
        public string name;
        public int no;
        public ElementId elementid;
        public List<ElementId> beams;
        public List<ElementId> columns;
        public List<ElementId> floors;
        public List<ElementId> walls;

        public Elevation(string name, ElementId elementid)
        {
            beams = new List<ElementId>();
            columns = new List<ElementId>();
            floors = new List<ElementId>();
            walls = new List<ElementId>();

            this.name = name;
            this.elementid = elementid;
            getno();
        }
        private void getno()
        {
            if (name[0] <= '9' && name[0]>='0')
            {
                no = name[0] - '0';
            }
            else
            {
                TaskDialog.Show("错误", "标高命名不规范：\n" + name);
            }
            if(name.Length > 1)
            {
                if (name[1] <= '9' && name[1] >= '0')
                {
                    no = name[1] - '0' + no * 10;
                }
            }
           // TaskDialog.Show("no", "" + no);
;        }
    }
}
