﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;

namespace HelloRevit
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class Class1 : IExternalCommand
    {

        private double P;
        private double Q1;
        private double Q2;
        private double Q3;
        private double Q4;
        private UIDocument uidoc;
        private Document doc;
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData commandData,
            ref string message, ElementSet elements)
        {
            // 得到当前文档的句柄。注意commandData通常是我们和Revit交互的中介。
            uidoc = commandData.Application.ActiveUIDocument;
            if(uidoc == null)
            {
                TaskDialog.Show("Warning!!!", "您还没打开工程文件，请进入工程后再次尝试");
            }
            doc = uidoc.Document;

            FilteredElementCollector collector = new FilteredElementCollector(doc);
            //ElementCategoryFilter filter = new ElementCategoryFilter(BuiltInCategory.OST_Walls);
            //ICollection<Element> founds = collector.WherePasses(filter).ToElements();
            //String information = "";
            //var walls = collector.OfClass(typeof(Wall));
            //foreach(var item in walls)
            //{  
            //    Options options = new Options();
            //    GeometryElement geometry = item.get_Geometry(options);

            //    foreach(GeometryObject obj in geometry)
            //    {
            //        int i = 0;
            //        Solid solid = obj as Solid;
            //        if(solid != null)
            //        {
            //            FaceArray faceArray = solid.Faces;
            //            foreach(Face face in faceArray)
            //            {
            //                information += "\n Face" + i + "的面积:" + face.Area.ToString();
            //                i ++;
            //            }
            //        }
            //    }
            //}

            //TaskDialog.Show("test", information);




            //// 得到当前的选择集，然后从选择集中得到已经选中的element id。
            //Selection selection = uidoc.Selection;
            //ICollection<ElementId> selectedIds = uidoc.Selection.GetElementIds();
            //if (0 == selectedIds.Count)
            //{
            //    // 没有被选中的element。
            //    TaskDialog.Show("Revit", "You haven't selected any elements.");
            //}
            //else
            //{

            //    // 打印所有选中element的id。
            //    String info = "Ids of selected elements in the document are: ";
            //    foreach (ElementId id in selectedIds)
            //    {
            //        Element elem = doc.GetElement(id);
            //        //info += "\n\t" + id.IntegerValue ;
            //        info += "\n\t" + elem.GetType();
            //    }

            //    TaskDialog.Show("Revit", info);
            //}

            //Form1 form1 = new Form1(uidoc);
            //form1.Show();
            MainPage main = new MainPage(uidoc);
            main.Show();

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

}



//UIDocument uiDoc = commandData.Application.ActiveUIDocument;
//Document doc = uiDoc.Document;
//Selection selection = uiDoc.Selection;
//Reference reference = selection.PickObject(ObjectType.Element);
//IList<Element> elementidset = selection.PickElementsByRectangle("Select by rectangle");
//Element element = doc.GetElement(reference);
//string texttoprint = "";

//foreach (Element elementid in elementidset)
//{
//    texttoprint = texttoprint + elementid.GetType().ToString();

//}
//if (texttoprint == "")
//{
//    texttoprint = "you select none";
//}
//TaskDialog.Show("Revit", texttoprint);

////获取全部元素
//UIDocument uiDoc = commandData.Application.ActiveUIDocument;

//FilteredElementCollector collectorAll = new FilteredElementCollector(uiDoc.Document);
//collectorAll.WherePasses(new LogicalOrFilter(new ElementIsElementTypeFilter(false), new ElementIsElementTypeFilter(true)));
//TaskDialog.Show("全部", collectorAll.Count().ToString());
////IsElement
//FilteredElementCollector collectorIs = new FilteredElementCollector(uiDoc.Document);
//collectorIs.WherePasses(new ElementIsElementTypeFilter(true));
//String a = "";
//foreach(Element elem in collectorIs)
//{
//    a += elem.GetType().ToString() + "/n";
//}
//TaskDialog.Show("IsElement", a);//collectorIs.Count().ToString());
////IsNotElement
//FilteredElementCollector collectorIsNot = new FilteredElementCollector(uiDoc.Document);
//collectorIsNot.WherePasses(new ElementIsElementTypeFilter(false));
//TaskDialog.Show("IsNotElement", collectorIsNot.Count().ToString());





//
