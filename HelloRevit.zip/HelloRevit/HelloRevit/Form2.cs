﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Form = System.Windows.Forms.Form;

namespace HelloRevit
{
    public partial class Form2 : Form
    {

        private Document doc;
        private UIDocument uidoc;

        private double P;
        private double Q1;
        private double Q2;
        private double Q3;
        private double Q4;
        private string failed;
        private string rankfail;
        double q1a = 0;
        double q1b = 0;
        double q2a = 0;
        double q2b = 0;
        double q2c = 0;
        double q2d = 0;
        double q3a = 0;
        double q3b = 0;
        double q3c = 0;
        double q3d = 0;
        private List<ListView> listviews = new List<ListView>();

        public Form2()
        {
            InitializeComponent();
        }

        public Form2(UIDocument uidoc)
        {
            InitializeComponent();
            this.uidoc = uidoc;
            this.doc = uidoc.Document;
            initiateListViews();
            //this.listView1.Items.Clear();
            //this.listView1.Columns.Clear();
            //listView1.View = System.Windows.Forms.View.Details;
            //listView1.FullRowSelect = true;
            //listView1.Columns.Add("种类", this.listView1.Width / 4, HorizontalAlignment.Left);
            //listView1.Columns.Add("id", this.listView1.Width / 4, HorizontalAlignment.Left);
            //listView1.Columns.Add("体积", this.listView1.Width / 4, HorizontalAlignment.Left);
            //listView1.Columns.Add("投影面积", this.listView1.Width / 4, HorizontalAlignment.Left);
            //listView1.Columns.Add("标注", this.listView1.Width / 4, HorizontalAlignment.Left);
            failed = "不合格评价比例如下：\n";
            getP();
            //TaskDialog.Show("不合格", failed);
            label49.Text = "不符合评价标准";
            label48.Text = Math.Round(P,2, MidpointRounding.AwayFromZero) +"";
            if (rank)
            {
                if(Q1<20)
                {
                    rankfail += "主体结构部分评价分值低于20分，不符合装配式建筑基本条件";
                    TaskDialog.Show("不符合基本条件", rankfail);
                    return;
                }
                if(Q2<10)
                {
                    rankfail += "围护墙和内隔墙部分评价分值低于10分，不符合装配式建筑基本条件";
                    TaskDialog.Show("不符合基本条件", rankfail);
                    return;
                }
                if (P < 0.5)
                {
                    rankfail += "装配率低于50%，不符合装配式建筑基本条件";
                    TaskDialog.Show("不符合基本条件", rankfail);
                    return;
                }
                if (P >= 0.91)
                {
                    label49.Text = "AAA级装配式建筑";
                }
                else if(P<0.91&&P>=0.76)
                {
                    label49.Text = "AA级装配式建筑";

                }
                else if(P<0.76&&P>0.5)
                {
                    label49.Text = "A级装配式建筑";
                }
            }
            else
            {
                rankfail += "主体结构竖向构件中预制品部件应用比例低于35%，不可进行装配式建筑等级评价";
                TaskDialog.Show("不符合基本条件", rankfail);
            }
        }

        private void initiateListViews()
        {
            listviews.Add(listView1);
            listviews.Add(listView2);
            listviews.Add(listView3);
            listviews.Add(listView4);
            listviews.Add(listView5);
            listviews.Add(listView7);

            foreach (ListView listview in listviews)
            {
                listview.Items.Clear();
                listview.Columns.Clear();
                listview.View = System.Windows.Forms.View.Details;
                listview.FullRowSelect = true;
                listview.Columns.Add("种类", this.listView1.Width / 5, HorizontalAlignment.Left);
                listview.Columns.Add("id", this.listView1.Width / 5, HorizontalAlignment.Left);
                listview.Columns.Add("体积", this.listView1.Width / 5, HorizontalAlignment.Left);
                listview.Columns.Add("投影面积", this.listView1.Width / 5, HorizontalAlignment.Left);
                listview.Columns.Add("标注", this.listView1.Width / 5, HorizontalAlignment.Left);
            }

            listView6.Items.Clear();
            listView6.Columns.Clear();
            listView6.View = System.Windows.Forms.View.Details;
            listView6.FullRowSelect = true;
            listView6.Columns.Add("不合格项目", this.listView1.Width / 4, HorizontalAlignment.Left);
            listView6.Columns.Add("比例", this.listView1.Width / 4, HorizontalAlignment.Left);
            listView6.Columns.Add("参考比例", this.listView1.Width / 4, HorizontalAlignment.Left);
            listView6.Columns.Add("分值", this.listView1.Width / 4, HorizontalAlignment.Left);
        }

        private void addIntoListView(string name, string id, string volume, string area, string usage, ListView listview)
        {
            ListViewItem temp = new ListViewItem(name);
            temp.SubItems.Add(id);
            temp.SubItems.Add(volume);
            temp.SubItems.Add(area);
            temp.SubItems.Add(usage);
            listview.Items.Add(temp);
        }

        private void addIntoListView(string name, string proportion, string referenceProportion, string referenceScore)
        {
            ListViewItem temp = new ListViewItem(name);
            temp.SubItems.Add(proportion+"%");
            temp.SubItems.Add(referenceProportion);
            temp.SubItems.Add(referenceScore);
            listView6.Items.Add(temp);
        }

        private double getInsertionRate(double proportion, double scorelow, double scorehigh, double decimallow, double decimalhigh)
        {
            double insertionRate;
            if(proportion >decimalhigh)
            {
                return scorehigh;
            }
            insertionRate = scorelow + (scorehigh - scorelow) * (proportion - decimallow) / (decimalhigh - decimallow);
            return insertionRate;
        }

        private bool rank = false;

        private double getP()
        {
            listView1.Items.Clear();
            //总装配率
            P = (getQ1() + getQ2() + getQ3()) / (100 - Q4);
            label85.Text = Q1 + "(/50)";
            label42.Text = Q2 + "(/20)";
            label44.Text = Q3 + "(/30)";
            label46.Text = Q4 + "";
            TaskDialog.Show("装配率", "装配率计算结果为：" + P + "\nQ4为" + Q4);
            return P;
        }
        private double getQ1()
        {//主体结构指标实际得分值
            Q1 = 0;
            double q1a = 0, q1b = 0;
            //内插法
            q1a = getQ1a();
            if (q1a < 0.35)
            {
                //TaskDialog.Show("计算提醒", "Q1a比值不合格：" + q1a + ",小于0.35，不参与计算");
                failed += "主体结构竖向构件Q1a比值不合格：" + q1a + ",小于0.35\n";
                addIntoListView("Q1竖向构件", "" + q1a * 100, "" + "35%-80%", "20-30");

                
                //不计入总分
                q1a = 0;
            }
            else
            {
                q1a = getInsertionRate(q1a, 20, 30, 0.35, 0.8);
                rank = true;
            }
            label12.Text = q1a + "";

            q1b = getQ1b();
            if (q1b < 0.7)
            {
                //输出操作等
                //TaskDialog.Show("计算提醒", "Q1b比值不合格：" + q1b + ",小于0.7，不参与计算");
                failed += "主体结构水平构件Q1b比值不合格：" + q1b + ",小于0.7\n";
                addIntoListView("Q1b水平构件", "" + q1b * 100, "" + "70%-80%", "10-20");
                
                //不计入总分
                q1b = 0;
            }
            else
            {
                q1b = getInsertionRate(q1b, 10, 20, 0.7, 0.8);
            }
            label13.Text = q1b + "";

            Q1 = q1a + q1b;

            //if (Q1 < 20)
            //{
            //    Q1 = 20;
            //}
            return Q1;
        }

        

        private double getQ1a()
        {
            

            //主体结构竖向构件中预制部品部件中预制混凝土体积之和
            //总体积
            //TODO:获取两个体积
            //遍历所有墙，同时计算承重墙的总体积 以及 预制的总体积
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            var walls = collector.OfClass(typeof(Wall));
            double allVolume = 0;
            double allPreVolume = 0;
            //TaskDialog.Show("test", "Q1a开始遍历墙，总数为：" + walls.Count());
            int i = 0;
            foreach (Element elem in walls)
            {
                Parameter preP = elem.LookupParameter("结构用途");
                if (preP != null)
                {
                    int a = preP.AsInteger();
                    if (a != 0)
                    {
                        i++;
                        Parameter volumeP = elem.LookupParameter("体积");
                        if (volumeP != null && volumeP.StorageType == StorageType.Double)
                        {
                            double volume = volumeP.AsDouble() * 0.3048 * 0.3048 * 0.3048;
                            allVolume += volume;
                            string wallName = elem.Name;

                            string annotation = "现浇墙";
                            if (wallName.Substring(0, 1) == "Y")
                            {
                                allPreVolume += volume;
                                annotation = "预制墙";
                            }
                            addIntoListView(wallName, elem.Id.IntegerValue.ToString(), volume + "", "无需计算", annotation,listView1);
                        }
                        else
                        {
                            TaskDialog.Show("warning", "墙的体积参数为空");
                        }
                    }

                }
            }
           // TaskDialog.Show("test", "遍历完墙：\nprevolume：\n" + allPreVolume + "\ntotalvolume：\n" + allVolume);
           // TaskDialog.Show("info", "承重墙个数：" + i);


            //遍历所有柱，计算总体积 以及 预制的总体积
            //var columns = collector.OfClass(typeof());
            collector = new FilteredElementCollector(doc);//OST_StructuralColumns
            var columns = collector.OfCategory(BuiltInCategory.OST_StructuralColumns)
                .OfClass(typeof(Autodesk.Revit.DB.FamilyInstance))
                .ToElements();
           //TaskDialog.Show("test", "开始遍历柱，总数为：" + columns.Count());

            foreach (var elem in columns)
            {

                Parameter volumeP = elem.LookupParameter("体积");
                if (volumeP != null && volumeP.StorageType == StorageType.Double)
                {
                    double volume = volumeP.AsDouble() * 0.3048 * 0.3048 * 0.3048;
                    allVolume += volume;
                    string columnName = elem.Name;

                    string annotation = "现浇柱";
                    if (columnName.Substring(0, 2) == "YZ")
                    {
                        annotation = "预制柱";
                        allPreVolume += volume;
                    }
                    addIntoListView(columnName, elem.Id.IntegerValue.ToString(), volume + "", "无需计算", annotation,listView1);

                }
                else
                {
                    TaskDialog.Show("warning", "柱的体积参数为空");
                }
            }
            //TaskDialog.Show("Q1a", "遍历完柱：\nQ1a.prevolume：\n" + allPreVolume + "\nQ1a.totalvolume：\n" + allVolume);

            if (allVolume != 0)
            {
                q1a = allPreVolume / allVolume;

            }
            else
                q1a = 0;
            label9.Text = allPreVolume+"";
            label10.Text = allVolume+"";
            label11.Text = q1a + "";
            if(allPreVolume == 0)
                Q4 += 30;
            return q1a;
        }
       
        private double getQ1b()
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            
            double PreArea = 0, TotalArea = 0;
            //主体结构梁、板、（楼梯）等构件中预制部品部件的应用比例
            //总面积

            //TODO:获取两个面积
            //遍历所有梁......
            var beams = collector.OfCategory(BuiltInCategory.OST_StructuralFraming).OfClass(typeof(FamilyInstance));
           // TaskDialog.Show("Q1b", "开始遍历梁，总数为：" + beams.Count());

            foreach (var beam in beams)
            {
                Options options = new Options();
                GeometryElement geometry = beam.get_Geometry(options);
                foreach (GeometryObject obj in geometry)
                {
                    //double volume;
                    if (obj is Solid) //如果元素gObj是实体
                    {
                        double area;
                        double areaA = 0, areaB = 0;
                        Solid sd = obj as Solid; //将gObj转换成实体
                        //volume = sd.Volume * 0.3048 * 0.3048 * 0.3048;
                        if (sd.Volume == 0)
                        {
                            continue;
                        }
                        else
                        {
                            foreach (Face face in sd.Faces)  //遍历sd.Faces中每一个面
                            {
                                area = face.Area * 0.3048 * 0.3048;//Revit中的单位是英尺,需进行单位转换
                                //此处要找到第二大的面积，即底面或是顶面
                                if (area > areaB)
                                {
                                    areaB = area;
                                }
                                if (area > areaA)
                                {
                                    areaB = areaA;
                                    areaA = area;
                                }
                            }
                            TotalArea += areaB;
                            string beamName = beam.Name;

                            string annotation = "现浇梁";
                            if (beamName.Substring(0, 2) == "YL")
                            {
                                annotation = "预制梁";
                                PreArea += areaB;
                            }
                            addIntoListView(beamName, beam.Id.IntegerValue.ToString(), "无需计算", areaB + "", annotation, listView2);

                            break;
                        }
                    }
                }
            }

           // TaskDialog.Show("Q1b", "\nQ1b.遍历完梁：\npre：\n" + PreArea + "\nQ1b.total：\n" + TotalArea);

            //遍历所有板......
            //var floors = collector.OfCategory(BuiltInCategory.OST_Floors).OfClass(typeof(FamilyInstance));
            collector = new FilteredElementCollector(doc);
            var floors = collector.OfClass(typeof(Floor));

            //TaskDialog.Show("Q1b", "开始遍历板，总数为：" + floors.Count());

            foreach (var floor in floors)
            {
                Parameter FloorParameter = floor.LookupParameter("面积");
                if (FloorParameter != null && FloorParameter.StorageType == StorageType.Double)
                {
                    double area = FloorParameter.AsDouble() * 0.3048 * 0.3048;
                    TotalArea += area;
                    string floorName = floor.Name;

                    string annotation = "现浇板";
                    if (floorName.Substring(0, 1) == "Y")
                    {
                        annotation = "预制板";
                        PreArea += area;
                    }
                    addIntoListView(floorName, floor.Id.IntegerValue.ToString(), "无需计算", area + "", annotation, listView2);

                }
            }
            //TaskDialog.Show("Q1b", "\nQ1b.遍历完板：\npre：" + PreArea + "\nQ1b.total：\n" + TotalArea);

            //遍历所有楼梯......（待定）

            if (TotalArea != 0)
            {
                q1b = PreArea / TotalArea;
            }
            else
                q1b = 0;
            label16.Text = PreArea + "";
            label15.Text = TotalArea + "";
            if (PreArea == 0)
                Q4 += 20;
            label14.Text = q1b + "";
            return q1b;
        }


        private double getQ2()
        {

            //非承重围护墙非砌筑部分
            q2a = 0;
            //围护墙采用墙体、保温、隔热、装饰一体化的应用比例
            q2b = 0;
            //内隔墙中非砌筑墙体的应用比例
            q2c = 0;
            //内隔墙采用墙体、管线、装修一体化的应用比例
            q2d = 0;

            FilteredElementCollector collector = new FilteredElementCollector(doc);
            var walls = collector.OfClass(typeof(Wall));
            double allOutsideNotWeightedWallArea = 0;//所有非承重围护墙

            double allNotQWallArea = 0;//所有非砌筑非承重围护墙

            double allOutsideWallArea = 0;//所有围护墙
            double allMultipleUsageWallArea = 0;//采用墙体、保温、隔热、装饰一体化的应用比例

            double allInsideWallArea = 0;//所有内隔墙面积
            double allInsideNotQWallArea = 0;//所有内隔墙非砌筑面积
            double allInsideMultipleUsageWallArea = 0;//所有采用墙体、保温、隔热、装饰一体化的内隔墙

            //TaskDialog.Show("test", "开始遍历墙，总数为：" + walls.Count());
            int w = 0;//围护墙
            int wm = 0;//一体化维护墙
            int nqw = 0;//非承重非砌体围护墙
            int n = 0;//内墙
            int nm = 0;//一体化内墙
            int nqn = 0;//非砌体内墙


            foreach (Element elem in walls)
            {

                Parameter preP = elem.LookupParameter("结构用途");
                if (preP != null)
                {
                    string wallName = elem.Name;

                    if (wallName.Substring(2, 1) == "W")///////////////////围护墙
                    {
                        string annotation = "围护墙";
                        w++;
                        Parameter areaP = elem.LookupParameter("面积");
                        double area = 0;
                        if (areaP != null && areaP.StorageType == StorageType.Double)
                        {
                            area = areaP.AsDouble() * 0.3048 * 0.3048;
                            allOutsideWallArea += area;//分母为所有外墙表面积
                            if (wallName.Substring(1, 1) == "M")//采用墙体、保温、隔热、装饰一体化的应用比例
                            {
                                annotation = "一体化围护墙";
                                wm++;
                                allMultipleUsageWallArea += area;
                            }
                            addIntoListView(wallName, elem.Id.IntegerValue.ToString(), "无需计算", area + "", annotation,listView4);


                            if (preP.AsInteger() == 0)////////////////////////////////////////非承重
                            {
                                annotation = "非承重砌体围护墙";//////////////////分母为所有非承重围护墙表面积
                                allOutsideNotWeightedWallArea += area;

                                if (wallName.Substring(0, 1) != "Q")
                                {
                                    nqw++;
                                    allNotQWallArea += area;
                                    annotation = "非承重非砌体围护墙";
                                }
                                addIntoListView(wallName, elem.Id.IntegerValue.ToString(), "无需计算", area + "", annotation,listView3);
                            }
                        }
                        else
                        {
                            TaskDialog.Show("warning", "墙的面积参数为空");
                        }
                    }
                    else if (wallName.Substring(2, 1) == "N")//内墙
                    {
                        string annotation = "内隔墙";
                        n++;
                        Parameter areaP = elem.LookupParameter("面积");
                        double area = 0;
                        if (areaP != null && areaP.StorageType == StorageType.Double)
                        {
                            area = areaP.AsDouble() * 0.3048 * 0.3048;
                            allInsideWallArea += area;//分母为所有内隔墙表面积
                            if (wallName.Substring(1, 1) == "M")//采用墙体、保温、隔热、装饰一体化的应用比例
                            {
                                annotation = "一体化内隔墙";
                                nm++;
                                allInsideMultipleUsageWallArea += area;
                            }


                            //////////////////分母为所有内隔墙表面积
                            if (wallName.Substring(0, 1) != "Q")
                            {
                                nqn++;
                                allInsideNotQWallArea += area;
                                annotation = "非砌体内隔墙";
                            }
                            addIntoListView(wallName, elem.Id.IntegerValue.ToString(), "无需计算", area + "", annotation,listView5);


                        }
                        else
                        {
                            TaskDialog.Show("warning", "墙的面积参数为空");
                        }

                    }

                }
            }

            //TaskDialog.Show("info", "\n围护墙个数：" + w
            //    + "\n一体化围护墙个数：" + wm
            //    + "\n非承重非砌体围护墙个数：" + nqw
            //    + "\n内墙个数：" + n
            //    + "\n一体化内墙个数：" + nm
            //    + "\n非砌体内墙个数：" + nqn);
            if (allOutsideNotWeightedWallArea != 0)
            {
                q2a = allNotQWallArea / allOutsideNotWeightedWallArea;
            }
            else
                q2a = 0;
            label24.Text = allNotQWallArea + "";
            label23.Text = allOutsideNotWeightedWallArea + "";
            if (allNotQWallArea == 0)
                Q4 += 5;
            label22.Text = q2a + "";

            if(allOutsideWallArea != 0)
            {
                q2b = allMultipleUsageWallArea / allOutsideWallArea;
            }
            else
                q2b = 0;
            label34.Text = allMultipleUsageWallArea + "";
            label33.Text = allOutsideWallArea + "";
            if (allMultipleUsageWallArea == 0)
                Q4 += 5;
            label32.Text = q2b + "";


            if (allOutsideWallArea != 0)
            {
                q2c = allInsideNotQWallArea / allInsideWallArea;
            }
            else
                q2c = 0;
           
            label54.Text = allInsideNotQWallArea + "";
            label53.Text = allInsideWallArea + "";
            if(allInsideNotQWallArea == 0)
                Q4 += 5;
            label52.Text = q2c + "";


            if (allOutsideWallArea != 0)
            {
                q2d = allInsideMultipleUsageWallArea / allInsideWallArea;
            }
            else
                q2d = 0;
            label64.Text = allInsideMultipleUsageWallArea + "";
            label63.Text = allInsideWallArea + "";
            if (allInsideMultipleUsageWallArea == 0)
                Q4 += 5;
            label62.Text = q2d + "";

            //  TaskDialog.Show("test", "遍历完墙：\nallNotQWallArea：\n"
            //    + allNotQWallArea + "\ntotalvolallOutsideWallAreaume：\n"
            //    + allOutsideNotWeightedWallArea);

            //内插法
            if (q2a < 0.8)
            {
                //输出操作等
                //   TaskDialog.Show("计算提醒", "Q2a比值不合格：" + q2a + "，小于0.8，不参与计算");
                failed += "Q2a比值不合格：" + q2a + "，小于0.8\n";
                addIntoListView("Q2a非承重围护墙非砌筑", "" + q2a*100, "" + "大于80%", "5");
                
                //不计入总分
                q2a = 0;
            }
            else
            {
                q2a = 5;
            }
            label21.Text = q2a+"";

            if (q2b < 0.5)
            {
                //输出操作等
                //   TaskDialog.Show("计算提醒", "Q2b比值不合格：" + q2b + "，小于0.5，不参与计算");
                failed += "Q2b比值不合格：" + q2b + "，小于0.5\n";
                addIntoListView("Q2b围护墙一体化", "" + q2b * 100, "" + "50%-80%", "2-5");
                
                //不计入总分
                q2b = 0;
            }
            else
            {
                q2b = getInsertionRate(q2b, 2, 5, 0.5, 0.8);
            }
            label31.Text = q2b + "";


            if (q2c < 0.5)
            {
                //输出操作等
                //   TaskDialog.Show("计算提醒", "Q2c比值不合格：" + q2c + "，小于0.5，不参与计算");
                failed += "Q2c比值不合格：" + q2c + "，小于0.5\n";
                addIntoListView("Q2c内隔墙非砌筑", "" + q2c * 100, "" + "大于50%", "5");
                
                //不计入总分
                q2c = 0;
            }
            else
            {
                q2c = 5;

            }
            label51.Text = q2c + "";


            if (q2d < 0.5)
            {
                //输出操作等
                //TaskDialog.Show("计算提醒", "Q2d比值不合格：" + q2d + "，小于0.5，不参与计算");
                failed += "Q2d比值不合格：" + q2d + "，小于0.5\n";
                addIntoListView("Q2d内隔墙一体化", "" + q2d * 100, "" + "50%-80%", "2-5");
                
                //不计入总分
                q2d = 0;
            }
            else
            {
                q2d = getInsertionRate(q2b, 2, 5, 0.5, 0.8);

            }
            label61.Text = q2d + "";

            Q2 = q2a + q2b + q2c + q2d;
            label42.Text = Q2 + "";
            //if (Q2 < 10)
            //{
            //    Q2 = 10;
            //}

            return Q2;
        }


        Util util;
        private double getQ3()
        {
            util = new Util();
            Form3 form3 = new Form3(util);
            form3.ShowDialog();

            //围护墙采用墙体、保温、隔热、装饰一体化的应用比例
            q3a = getq3a();
            q3b = getq3b();
            q3c = getq3c();
            q3d = getq3d();

            //数据不达标时的处理
            if (q3a < 0.7)
            {
                //TaskDialog.Show("计算提醒", "Q3a比值不合格：" + q3a + "，小于0.7，不参与计算");
                failed += "Q3a比值不合格：" + q3a + "，小于0.7\n";
                addIntoListView("Q3a干式工法楼面、地面", "" + q3a * 100, "" + "大于70%", "6");
                
                //不计入总分
                q3a = 0;
            }
            else
            {
                q3a = 6;
            }
            label41.Text = q3a + "";

            if (q3b < 0.7)
            {
                //输出操作等
                //TaskDialog.Show("计算提醒", "Q3b比值不合格：" + q3b + "，小于0.7，不参与计算");
                failed += "Q3b比值不合格：" + q3b + "，小于0.7\n";
                addIntoListView("Q3b集成厨房", "" + q3b * 100, "" + "70%-90%", "3-6");
                
                //不计入总分
                q3b = 0;
            }
            else
            {
                q3b = getInsertionRate(q3b, 3, 6, 0.7, 0.9);
            }
            label99.Text = q3b + "";

            if (q3c < 0.7)
            {
                //输出操作等
                //TaskDialog.Show("计算提醒", "Q3c比值不合格：" + q3c + "，小于0.7，不参与计算");
                failed += "Q3c比值不合格：" + q3c + "，小于0.7\n";
                addIntoListView("Q3c集成卫生间", "" + q3c * 100, "" + "70%-90%", "3-6");
                
                //不计入总分
                q3c = 0;
            }
            else
            {
                q3c = getInsertionRate(q3c, 3, 6, 0.7, 0.9);
            }
            label89.Text = q3c + "";

            if (q3d < 0.5)
            {
                //输出操作等
                //TaskDialog.Show("计算提醒", "Q3d比值不合格：" + q3c + "，小于0.7，不参与计算");
                failed += "Q3d比值不合格：" + q3d + "，小于0.7\n";
                addIntoListView("Q3d管线分离", "" + q3d * 100, "" + "50%-70%", "4-6");

               
                //不计入总分
                q3d = 0;
            }
            else
            {
                q3d = getInsertionRate(q3d, 4, 6, 0.5, 0.7);
            }
            label109.Text = q3d + "";

            Q3 = 6 + q3a + q3b + q3c + q3d;
            label44.Text = Q3 + "";
            return Q3;
        }

        private double getq3a()
        {
            //干式工法楼面、地面
            double q3a = 0;
            double floorArea = 0;
            double dryArea = 0;
           


            //遍历所有板......
            //var floors = collector.OfCategory(BuiltInCategory.OST_Floors).OfClass(typeof(FamilyInstance));
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            collector = new FilteredElementCollector(doc);
            var floors = collector.OfClass(typeof(Floor));

            //TaskDialog.Show("Q1b", "开始遍历板，总数为：" + floors.Count());
            foreach (var floor in floors)
            {
                Parameter FloorParameter = floor.LookupParameter("面积");
                if (FloorParameter != null && FloorParameter.StorageType == StorageType.Double)
                {
                    double area = FloorParameter.AsDouble() * 0.3048 * 0.3048;
                    floorArea += area;
                    string floorName = floor.Name;

                    string annotation = "板";
                    if (floorName.Substring(2, 1) == "G")
                    {
                        annotation = "干式工法板";
                        dryArea += area;
                    }
                    addIntoListView(floorName, floor.Id.IntegerValue.ToString(), "无需计算", area + "", annotation, listView7);

                }
            }

            if (floorArea != 0)
            {
                q3a = dryArea / floorArea;
            }
            else
                q3a = 0;

            if (dryArea == 0)
                Q4 += 6;
            //if (util.a2 != 0)
            //{
            //    q3a = util.a1 / util.a2;
            //}
            //else
            //    q3a = 0;

            
            label73.Text = dryArea + "";
            label72.Text = floorArea + "";
            label71.Text = q3a + "";
            return q3a;
        }

        private double getq3b()
        {
            //集成厨房
            double q3b = 0;
            //遍历操作
            label102.Text = util.b1 + "";
            label101.Text = util.b2 + "";
            if (util.b2 != 0)
            {
                q3b = util.b1 / util.b2;

            }
            else
                q3b = 0;
            if (util.b1 == 0)
                Q4 += 6;
            label100.Text = q3b + "";

            return q3b;
        }
        private double getq3c()
        {
            //集成卫生间
            double q3c = 0;
            //遍历操作
            label92.Text = util.c1 + "";
            label91.Text = util.c2 + "";
            if (util.c2 != 0)
            {
                q3c = util.c1 / util.c2;

            }
            else
                q3c = 0;
            if (util.c1 == 0)
                Q4 += 6;
            label90.Text = q3c + "";
            return q3c;
        }

        private double getq3d()
        {
            //管线分离
            double q3d = 0;
            //遍历操作
            label112.Text = util.d1 + "";
            label111.Text = util.d2 + "";
            if (util.d2 != 0)
            {
                q3d = util.d1 / util.d2;

            }
            else
                q3d = 0;
            if (util.d1 == 0)
                Q4 += 6;
            label110.Text = q3d + "";

            return q3d;
        }

        private double getQ4()
        {
            return Q4;
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label46_Click(object sender, EventArgs e)
        {
  
        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
    }
}
