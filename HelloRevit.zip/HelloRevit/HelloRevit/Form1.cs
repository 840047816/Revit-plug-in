﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Form = System.Windows.Forms.Form;
namespace HelloRevit
{
    public partial class Form1 : Form
    {
        private UIDocument uidoc;
        private Document doc;
        public Form1(UIDocument uidoc)
        {
            InitializeComponent();
            this.uidoc = uidoc;
            this.doc = uidoc.Document;
            this.listView1.Items.Clear();
            this.listView1.Columns.Clear();
            listView1.View = System.Windows.Forms.View.Details;
            listView1.FullRowSelect = true;
            listView1.Columns.Add("种类", this.listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("id", this.listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("体积", this.listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("投影面积", this.listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("标注", this.listView1.Width / 4, HorizontalAlignment.Left);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            getAllWalls();
        }

        public void addIntoListView0(string name, string id, string volume, string area, string usage)
        {
            ListViewItem temp = new ListViewItem(name);
            temp.SubItems.Add(id);
            temp.SubItems.Add(volume);
            temp.SubItems.Add(area);
            temp.SubItems.Add(usage);

            listView1.Items.Add(temp);
        }

        private void getAllGeoInfo()
        {
            listView1.Items.Clear();
            Selection selection = uidoc.Selection;
            ICollection<ElementId> elementidset = uidoc.Selection.GetElementIds();
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            var columns = collector.OfCategory(BuiltInCategory.OST_StructuralFraming).OfClass(typeof(FamilyInstance));
            double volume = -1, area = -1;
            foreach (var itemid in elementidset)
            {
                Element item = doc.GetElement(itemid);
                Options options = new Options();
                GeometryElement geometry = item.get_Geometry(options);
                foreach (GeometryObject obj in geometry)
                {
                    if (obj is Solid) //如果元素gObj是实体
                    {
                        Solid sd = obj as Solid; //将gObj转换成实体
                        string faces = "";
                        foreach (Face face in sd.Faces)  //遍历sd.Faces中每一个面
                        {
                            area = face.Area * 0.3048 * 0.3048;//Revit中的单位是英尺,需进行单位转换
                            faces += area + "\n";
                        }
                        volume = sd.Volume * 0.3048 * 0.3048 * 0.3048;
                        if (volume == 0)
                        {
                            continue;
                        }
                        else
                        {
                            break;
                        }
                        TaskDialog.Show("test", "体积\n" + volume + "\n面积\n" + faces);
                    }
                }
            }
        }

        private void getAllWalls()
        {
            Selection selection = uidoc.Selection;
            ICollection<ElementId> elementidset = uidoc.Selection.GetElementIds();
            FilteredElementCollector collector = new FilteredElementCollector(doc);

            String information = "";
            var walls = collector.OfClass(typeof(Wall));
            TaskDialog.Show("test", elementidset.Count.ToString());

            foreach (var itemid in elementidset)
            {
                //id转换为element
                var item = doc.GetElement(itemid);

                Options options = new Options();
                double area = 0, volume = 0;
                GeometryElement geometry = item.get_Geometry(options);
                if (geometry.Count() == 0)
                {
                    TaskDialog.Show("test", "生成geometry失败");
                }
                foreach (GeometryObject obj in geometry)
                {
                    int i = 0;
                    Solid solid = obj as Solid;
                    if (solid != null)
                    {
                        FaceArray faceArray = solid.Faces;
                        area = faceArray.get_Item(0).Area;
                        volume = solid.Volume;
                        foreach (Face face in faceArray)
                        {
                            //TaskDialog.Show("area", face.Area.ToString());
                            information += "\n Face" + i + "的面积:" + face.Area.ToString();
                            i++;
                        }
                    }
                    else
                    {
                        TaskDialog.Show("test", "未生成solid");
                    }
                }

                addIntoListView0(item.GetType().ToString(),
                        item.Id.IntegerValue.ToString(),
                        volume.ToString(),
                        area.ToString(),
                        "暂无标注");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //参数测试
            listView1.Items.Clear();
            Selection selection = uidoc.Selection;
            ICollection<ElementId> selectedIds = uidoc.Selection.GetElementIds();
            if (0 == selectedIds.Count)
            {
                // 没有被选中的element。
                TaskDialog.Show("Revit", "You haven't selected any elements.");
            }
            else
            {
                double volume = -1;
                foreach (ElementId id in selectedIds)
                {
                    volume = -1;
                    Element elem = doc.GetElement(id);
                    ParameterSet parameterset = elem.Parameters;
                    string paramstring = "";
                    TaskDialog.Show("参数个数", parameterset.Size.ToString());
                    foreach (Parameter param in parameterset)
                    {
                        paramstring += "\n" + param.Definition.Name + "   " + param.StorageType + "    " + param.ToString();
                    }
                    TaskDialog.Show("test", paramstring);
                    //Parameter paramVolume = elem.LookupParameter("体积");
                    //if (paramVolume != null && paramVolume.StorageType == StorageType.Double)
                    //{
                    //    volume = paramVolume.AsDouble();
                    //}
                    //else if (paramVolume == null)
                    //{
                    //    TaskDialog.Show("test", "体积参数对象为空");
                    //}
                    //volume = volume * 0.3048 * 0.3048 * 0.3048;
                    //addIntoListView0(elem.Name, elem.Id.ToString(), volume+"", "暂无area");
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            getAllGeoInfo();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            Selection selection = uidoc.Selection;
            ICollection<ElementId> selectedIds = uidoc.Selection.GetElementIds();
            if (0 == selectedIds.Count)
            {
                // 没有被选中的element。
                TaskDialog.Show("Revit", "You haven't selected any elements.");
            }
            else
            {
                double volume = -1;
                foreach (ElementId id in selectedIds)
                {
                    Element elem = doc.GetElement(id);
                    ParameterSet parameterset = elem.Parameters;
                    if (elem.GetType() + "" == "Autodesk.Revit.DB.FamilyInstance")
                    {
                        elem = (FamilyInstance)doc.GetElement(id);
                    }
                    string elementInfo = "";
                    elementInfo += "name: " + elem.Name + "\n";
                    elementInfo += "type: " + elem.GetType() + "\n";
                    elementInfo += "category: " + elem.Category.Name + "\n";
                    TaskDialog.Show("test", elementInfo);
                }
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Selection selection = uidoc.Selection;
            ICollection<ElementId> selectedIds = uidoc.Selection.GetElementIds();
            foreach (ElementId elemid in selectedIds)
            {
                Element elem = doc.GetElement(elemid);
                if (elem.GetType() + "" == "Autodesk.Revit.DB.FamilyInstance")
                {
                    elem = (FamilyInstance)doc.GetElement(elemid);
                }
                Parameter beamArea = elem.get_Parameter(BuiltInParameter.STRUCTURAL_ANALYTICAL_BEAM_HORIZONTAL_PROJECTION_PLANE);
                TaskDialog.Show("test", beamArea.StorageType.ToString());
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Q1 = getQ1();
            label1.Text = Q1 + "";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Q2 = getQ2();
            label2.Text = Q2 + "";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Q3 = getQ3();
            label3.Text = Q3 + "";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            P = getP();
            label4.Text = P + "";
        }


        private double P;
        private double Q1;
        private double Q2;
        private double Q3;
        private double Q4;

        private double getInsertionRate(double proportion, double scorelow, double scorehigh, double decimallow, double decimalhigh)
        {
            double insertionRate;
            insertionRate = scorelow + (scorehigh - scorelow) * (proportion - decimallow) / (decimalhigh - decimallow);
            return insertionRate;
        }

        private double getP()
        {
            listView1.Items.Clear();
            //总装配率
            P = (getQ1() + getQ2() + getQ3()) / (100 - Q4);
            label1.Text = Q1+"";
            label2.Text = Q2+"";
            label3.Text = Q3+"";
            label4.Text = Q4+"";
            TaskDialog.Show("装配率", "装配率计算结果为：" + P+"\nQ4为"+Q4);
            return P;
        }
        private double getQ1()
        {//主体结构指标实际得分值
            Q1 = 0;
            double q1a = 0, q1b = 0;
            //内插法
            q1a = getQ1a();
            if (q1a < 0.35)
            {
                //输出操作等
                TaskDialog.Show("计算提醒", "Q1a比值不合格：" + q1a + ",小于0.35，不参与计算");
                Q4 += 30;
                //不计入总分
                q1a = 0;
            }
            else
            {
                q1a = getInsertionRate(q1a, 20, 30, 0.35, 0.8);
            }

            q1b = getQ1b();
            if (q1b < 0.7)
            {
                //输出操作等
                TaskDialog.Show("计算提醒", "Q1b比值不合格：" + q1b + ",小于0.7，不参与计算");
                Q4+=20;
                //不计入总分
                q1b = 0;
            }
            else
            {
                q1b = getInsertionRate(q1b, 10, 20, 0.7, 0.8);
            }

            Q1 = q1a + q1b;
            if (Q1 < 20)
            {
                Q1 = 20;
            }
            return Q1;
        }


        private double getQ1a()
        {
            double q1a = 0;

            //主体结构竖向构件中预制部品部件中预制混凝土体积之和
            //总体积
            //TODO:获取两个体积
            //遍历所有墙，同时计算承重墙的总体积 以及 预制的总体积
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            var walls = collector.OfClass(typeof(Wall));
            double allVolume = 0;
            double allPreVolume = 0;
            TaskDialog.Show("test", "Q1a开始遍历墙，总数为：" + walls.Count());
            int i = 0;
            foreach (Element elem in walls)
            {
                Parameter preP = elem.LookupParameter("结构用途");
                if (preP != null)
                {
                    int a = preP.AsInteger();
                    if (a != 0)
                    {
                        i++;
                        Parameter volumeP = elem.LookupParameter("体积");
                        if (volumeP != null && volumeP.StorageType == StorageType.Double)
                        {
                            double volume = volumeP.AsDouble() * 0.3048 * 0.3048 * 0.3048;
                            allVolume += volume;
                            string wallName = elem.Name;

                            string annotation = "现浇墙";
                            if (wallName.Substring(0, 1) == "Y")
                            {
                                allPreVolume += volume;
                                annotation = "预制墙";
                            }
                            addIntoListView0(wallName, elem.Id.IntegerValue.ToString(), volume + "", "无需计算", annotation);
                        }
                        else
                        {
                            TaskDialog.Show("warning", "墙的体积参数为空");
                        }
                    }

                }
            }
            TaskDialog.Show("test", "遍历完墙：\nprevolume：\n" + allPreVolume + "\ntotalvolume：\n" + allVolume);
            TaskDialog.Show("info", "承重墙个数：" + i);


            //遍历所有柱，计算总体积 以及 预制的总体积
            //var columns = collector.OfClass(typeof());
            collector = new FilteredElementCollector(doc);//OST_StructuralColumns
            var columns = collector.OfCategory(BuiltInCategory.OST_StructuralColumns)
                .OfClass(typeof(Autodesk.Revit.DB.FamilyInstance))
                .ToElements();
            TaskDialog.Show("test", "开始遍历柱，总数为：" + columns.Count());

            foreach (var elem in columns)
            {

                Parameter volumeP = elem.LookupParameter("体积");
                if (volumeP != null && volumeP.StorageType == StorageType.Double)
                {
                    double volume = volumeP.AsDouble() * 0.3048 * 0.3048 * 0.3048;
                    allVolume += volume;
                    string columnName = elem.Name;

                    string annotation = "现浇柱";
                    if (columnName.Substring(0, 3) == "YZX")
                    {
                        annotation = "预制柱";
                        allPreVolume += volume;
                    }
                    addIntoListView0(columnName, elem.Id.IntegerValue.ToString(), volume + "", "无需计算", annotation);

                }
                else
                {
                    TaskDialog.Show("warning", "柱的体积参数为空");
                }
            }
            TaskDialog.Show("Q1a", "遍历完柱：\nQ1a.prevolume：\n" + allPreVolume + "\nQ1a.totalvolume：\n" + allVolume);

            q1a = allPreVolume / allVolume;
            return q1a;
        }

        private double getQ1b()
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            double q1b = 0;
            double PreArea = 0, TotalArea = 0;
            //主体结构梁、板、（楼梯）等构件中预制部品部件的应用比例
            //总面积

            //TODO:获取两个面积
            //遍历所有梁......
            var beams = collector.OfCategory(BuiltInCategory.OST_StructuralFraming).OfClass(typeof(FamilyInstance));
            TaskDialog.Show("Q1b", "开始遍历梁，总数为：" + beams.Count());

            foreach (var beam in beams)
            {
                Options options = new Options();
                GeometryElement geometry = beam.get_Geometry(options);
                foreach (GeometryObject obj in geometry)
                {
                    //double volume;
                    if (obj is Solid) //如果元素gObj是实体
                    {
                        double area;
                        double areaA = 0, areaB = 0;
                        Solid sd = obj as Solid; //将gObj转换成实体
                        //volume = sd.Volume * 0.3048 * 0.3048 * 0.3048;
                        if (sd.Volume == 0)
                        {
                            continue;
                        }
                        else
                        {
                            foreach (Face face in sd.Faces)  //遍历sd.Faces中每一个面
                            {
                                area = face.Area * 0.3048 * 0.3048;//Revit中的单位是英尺,需进行单位转换
                                //此处要找到第二大的面积，即底面或是顶面
                                if (area > areaB)
                                {
                                    areaB = area;
                                }
                                if (area > areaA)
                                {
                                    areaB = areaA;
                                    areaA = area;
                                }
                            }
                            TotalArea += areaB;
                            string beamName = beam.Name;

                            string annotation = "现浇梁";
                            if (beamName.Substring(0, 2) == "YL")
                            {
                                annotation = "预制梁";
                                PreArea += areaB;
                            }
                            addIntoListView0(beamName, beam.Id.IntegerValue.ToString(), "无需计算", areaB + "", annotation);

                            break;
                        }
                    }
                }
            }

            TaskDialog.Show("Q1b", "\nQ1b.遍历完梁：\npre：\n" + PreArea + "\nQ1b.total：\n" + TotalArea);

            //遍历所有板......
            //var floors = collector.OfCategory(BuiltInCategory.OST_Floors).OfClass(typeof(FamilyInstance));
            collector = new FilteredElementCollector(doc);
            var floors = collector.OfClass(typeof(Floor));

            TaskDialog.Show("Q1b", "开始遍历板，总数为：" + floors.Count());

            foreach (var floor in floors)
            {
                Parameter FloorParameter = floor.LookupParameter("面积");
                if (FloorParameter != null && FloorParameter.StorageType == StorageType.Double)
                {
                    double area = FloorParameter.AsDouble() * 0.3048;
                    TotalArea += area;
                    string floorName = floor.Name;

                    string annotation = "现浇板";
                    if (floorName.Substring(0, 1) == "Y")
                    {
                        annotation = "预制板";
                        PreArea += area;
                    }
                    addIntoListView0(floorName, floor.Id.IntegerValue.ToString(), "无需计算", area + "", annotation);

                }
            }
            TaskDialog.Show("Q1b", "\nQ1b.遍历完板：\npre：" + PreArea + "\nQ1b.total：\n" + TotalArea);

            //遍历所有楼梯......（待定）

            q1b = PreArea / TotalArea;
            return q1b;
        }


        private double getQ2()
        {

            //非承重围护墙非砌筑部分
            double q2a = 0;
            //围护墙采用墙体、保温、隔热、装饰一体化的应用比例
            double q2b = 0;
            //内隔墙中非砌筑墙体的应用比例
            double q2c = 0;
            //内隔墙采用墙体、管线、装修一体化的应用比例
            double q2d = 0;

            FilteredElementCollector collector = new FilteredElementCollector(doc);
            var walls = collector.OfClass(typeof(Wall));
            double allOutsideNotWeightedWallArea = 0;//所有非承重围护墙

            double allNotQWallArea = 0;//所有非砌筑非承重围护墙

            double allOutsideWallArea = 0;//所有围护墙
            double allMultipleUsageWallArea = 0;//采用墙体、保温、隔热、装饰一体化的应用比例

            double allInsideWallArea = 0;//所有内隔墙面积
            double allInsideNotQWallArea = 0;//所有内隔墙非砌筑面积
            double allInsideMultipleUsageWallArea = 0;//所有采用墙体、保温、隔热、装饰一体化的内隔墙

            TaskDialog.Show("test", "开始遍历墙，总数为：" + walls.Count());
            int w = 0;//围护墙
            int wm = 0;//一体化维护墙
            int nqw = 0;//非承重非砌体围护墙
            int n = 0;//内墙
            int nm = 0;//一体化内墙
            int nqn = 0;//非砌体内墙


            foreach (Element elem in walls)
            {

                Parameter preP = elem.LookupParameter("结构用途");
                if (preP != null)
                {
                    string wallName = elem.Name;

                    if (wallName.Substring(2, 1) == "W")///////////////////围护墙
                    {
                        string annotation = "";
                        w++;
                        Parameter areaP = elem.LookupParameter("面积");
                        double area = 0;
                        if (areaP != null && areaP.StorageType == StorageType.Double)
                        {
                            area = areaP.AsDouble() * 0.3048 * 0.3048;
                            allOutsideWallArea += area;//分母为所有外墙表面积
                            if (wallName.Substring(1, 1) == "M")//采用墙体、保温、隔热、装饰一体化的应用比例
                            {
                                annotation = "一体化外墙";
                                wm++;
                                allMultipleUsageWallArea += area;
                            }

                            int a = preP.AsInteger();
                            if (a == 0)////////////////////////////////////////非承重
                            {
                                annotation = "非承重砌体外墙";//////////////////分母为所有非承重围护墙表面积
                                allOutsideNotWeightedWallArea += area;

                                if (wallName.Substring(0, 1) != "Q")
                                {
                                    nqw++;
                                    allNotQWallArea += area;
                                    annotation = "非承重非砌体外墙";
                                }
                            }
                            addIntoListView0(wallName, elem.Id.IntegerValue.ToString(), "无需计算", area + "", annotation);

                        }
                        else
                        {
                            TaskDialog.Show("warning", "墙的面积参数为空");
                        }
                    }
                    else if (wallName.Substring(2, 1) == "N")//内墙
                    {
                        string annotation = "";
                        n++;
                        Parameter areaP = elem.LookupParameter("面积");
                        double area = 0;
                        if (areaP != null && areaP.StorageType == StorageType.Double)
                        {
                            area = areaP.AsDouble() * 0.3048 * 0.3048;
                            allInsideWallArea += area;//分母为所有内隔墙表面积
                            if (wallName.Substring(1, 1) == "M")//采用墙体、保温、隔热、装饰一体化的应用比例
                            {
                                annotation = "一体化内墙";
                                nm++;
                                allInsideMultipleUsageWallArea += area;
                            }


                            //////////////////分母为所有内隔墙表面积
                            allOutsideNotWeightedWallArea += area;
                            if (wallName.Substring(0, 1) != "Q")
                            {
                                nqn++;
                                allInsideNotQWallArea += area;
                                annotation = "非砌体墙";
                            }
                            addIntoListView0(wallName, elem.Id.IntegerValue.ToString(), "无需计算", area + "", annotation);


                        }
                        else
                        {
                            TaskDialog.Show("warning", "墙的面积参数为空");
                        }

                    }

                }
            }

            TaskDialog.Show("info", "\n围护墙个数：" + w
                + "\n一体化围护墙个数：" + wm
                + "\n非承重非砌体围护墙个数：" + nqw
                + "\n内墙个数：" + n
                + "\n一体化内墙个数：" + nm
                + "\n非砌体内墙个数：" + nqn);
            q2a = allNotQWallArea / allOutsideNotWeightedWallArea;
            q2b = allMultipleUsageWallArea / allOutsideWallArea;
            q2c = allInsideNotQWallArea / allInsideWallArea;
            q2d = allInsideMultipleUsageWallArea / allInsideWallArea;

            TaskDialog.Show("test", "遍历完墙：\nallNotQWallArea：\n"
                + allNotQWallArea + "\ntotalvolallOutsideWallAreaume：\n"
                + allOutsideNotWeightedWallArea);

            //内插法
            if (q2a < 0.8)
            {
                //输出操作等
                TaskDialog.Show("计算提醒", "Q2a比值不合格：" + q2a + "，小于0.8，不参与计算");
                Q4 += 5;
                //不计入总分
                q2a = 0;
            }
            q2a = q2a * 5;
            if (q2b < 0.5)
            {
                //输出操作等
                TaskDialog.Show("计算提醒", "Q2b比值不合格：" + q2b + "，小于0.5，不参与计算");
                Q4 += 5;
                //不计入总分
                q2b = 0;
            }
            else
            {
                q2b = getInsertionRate(q2b, 2, 5, 0.5, 0.8);
            }
            if (q2c < 0.5)
            {
                //输出操作等
                TaskDialog.Show("计算提醒", "Q2c比值不合格：" + q2c + "，小于0.5，不参与计算");
                Q4 += 5;
                //不计入总分
                q2c = 0;
            }
            q2c = q2c * 5;
            if (q2d < 0.5)
            {
                //输出操作等
                TaskDialog.Show("计算提醒", "Q2d比值不合格：" + q2d + "，小于0.5，不参与计算");
                Q4 += 5;
                //不计入总分
                q2d = 0;
            }
            else
            {
                q2d = getInsertionRate(q2b, 2, 5, 0.5, 0.8);
            }

            Q2 = q2a + q2b + q2c + q2d;

            //if (Q2 < 10)
            //{
            //    Q2 = 10;
            //}

            return Q2;
        }
        private double getQ3()
        {
            //围护墙采用墙体、保温、隔热、装饰一体化的应用比例
            double q3a = getq3a(),
                q3b = getq3b(),
                q3c = getq3c(),
                q3d = getq3d();

            //数据不达标时的处理
            if (q3a < 0.7)
            {
                TaskDialog.Show("计算提醒", "Q3a比值不合格：" + q3a + "，小于0.7，不参与计算");
                Q4 += 6;
                //不计入总分
                q3a = 0;
            }
            q3a = q3a * 6;

            if (q3b < 0.7)
            {
                //输出操作等
                TaskDialog.Show("计算提醒","Q3b比值不合格：" + q3b + "，小于0.7，不参与计算");

                Q4 += 6;
                //不计入总分
                q3b = 0;
            }
            else
            {
                q3b = getInsertionRate(q3b, 3, 6, 0.7, 0.9);
            }

            if (q3c < 0.7)
            {
                //输出操作等
                TaskDialog.Show("计算提醒", "Q3c比值不合格：" + q3c + "，小于0.7，不参与计算");
                Q4 += 6;
                //不计入总分
                q3c = 0;
            }
            else
            {
                q3c = getInsertionRate(q3c, 3, 6, 0.7, 0.9);
            }

            if (q3d < 0.5)
            {
                //输出操作等
                TaskDialog.Show("计算提醒", "Q3d比值不合格：" + q3c + "，小于0.7，不参与计算");
                Q4 += 6;
                //不计入总分
                q3d = 0;
            }
            else
            {
                q3d = getInsertionRate(q3d, 4, 6, 0.5, 0.7);
            }

            Q3 = 6 + q3a + q3b + q3c + q3d;
            label3.Text = Q3 + "";
            return Q3;
        }

        private double getq3a()
        {
            //干式工法楼面、地面
            double q3a = 0;
            //遍历操作

            
            return q3a;
        }

        private double getq3b()
        {
            //集成厨房
            double q3b = 0;
            //遍历操作

            
            return q3b;
        }
        private double getq3c()
        {
            //集成卫生间
            double q3c = 0;
            //遍历操作

            
            return q3c;
        }

        private double getq3d()
        {
            //管线分离
            double q3d = 0;
            //遍历操作

            return q3d;
        }

        private double getQ4()
        {
            return Q4;
        }

        private void button10_Click(object sender, EventArgs e)
        {

            //Selection selection = uidoc.Selection;
            //ICollection<ElementId> selectedIds = uidoc.Selection.GetElementIds();
            //foreach (ElementId elemid in selectedIds)
            //{
            //    Element elem = doc.GetElement(elemid);
            //    Element level = doc.GetElement(elem.LevelId);
            //    ///!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            //    TaskDialog.Show("标高测试", "" + level.Name);
            //}

            //显示所有标高
            FilteredElementCollector collector = new FilteredElementCollector(uidoc.Document);
            ICollection<Element> levels = collector.OfClass(typeof(Level)).ToElements();
            string allLevels = "";
            foreach (Element level in levels)
            {
                allLevels += level.Name + "\n";
            }
            TaskDialog.Show("所有标高", allLevels);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Selection selection = uidoc.Selection;
            ICollection<ElementId> selectedIds = uidoc.Selection.GetElementIds();
            if (0 == selectedIds.Count)
            {
                // 没有被选中的element。
                TaskDialog.Show("Revit", "You haven't selected any elements.");
            }
            else
            {
                foreach (ElementId id in selectedIds)
                {
                    Element elem = doc.GetElement(id);
                    Parameter parameter = elem.LookupParameter("标高");
                    string paramstring = "";
                    Element f = doc.GetElement(parameter.AsElementId());
                    paramstring = f.Name ;
                    TaskDialog.Show("test", paramstring);
                }
            }
        }
        private List<Elevation> elevations ;
        private void button12_Click(object sender, EventArgs e)
        {
            //获得所有标高
            FilteredElementCollector collector = new FilteredElementCollector(uidoc.Document);
            ICollection<Element> levels = collector.OfClass(typeof(Level)).ToElements();
            elevations = new List<Elevation>();
            foreach (Element level in levels)
            {
                elevations.Add(new Elevation(level.Name, level.Id));
            }
            TaskDialog.Show("标高", "已获得所有标高!");

            //遍历所有墙
            FilteredElementCollector wallcollector = new FilteredElementCollector(doc);
            ICollection<Element> walls = wallcollector.OfClass(typeof(Wall)).ToElements();
            foreach (Element wall in walls)
            {
                Parameter parameter = wall.LookupParameter("底部限制条件");
                Element f = doc.GetElement(parameter.AsElementId());
                Elevation ele = elevations.Find(item => item.name == f.Name);//在所有标高中查找该元素对应的标高对象
                ele.walls.Add(wall.Id);
            }
            //遍历所有板
            FilteredElementCollector floorcollector = new FilteredElementCollector(doc);
            ICollection<Element> floors = floorcollector.OfClass(typeof(Floor)).ToElements();
            TaskDialog.Show("123", "板的数量" + floors.Count());
            foreach (Element floor in floors)
            {
                Parameter parameter = floor.LookupParameter("标高");
                Element f = doc.GetElement(parameter.AsElementId());
                Elevation ele = elevations.Find(item => item.name == f.Name);//在所有标高中查找该元素对应的标高对象
                TaskDialog.Show("找到ele对象", ele.name + "   " + ele.no + "   ");
                ele.floors.Add(floor.Id);
                TaskDialog.Show("count", "" + ele.floors.Count());
            }

            //遍历所有梁
            FilteredElementCollector beamcollector = new FilteredElementCollector(doc);
            ICollection<Element> beams = beamcollector.OfCategory(BuiltInCategory.OST_StructuralFraming).OfClass(typeof(FamilyInstance)).ToElements();
            TaskDialog.Show("123", "梁的数量" + beams.Count());

            foreach (Element beam in beams)
            {
                Parameter parameter = beam.LookupParameter("参照标高");
                Element f = doc.GetElement(parameter.AsElementId());
                if (f == null)
                {
                    TaskDialog.Show("错误", "未能根据id找到标高对象    " + parameter.AsElementId());
                }
                Elevation ele = elevations.Find(item => item.name == f.Name);//在所有标高中查找该元素对应的标高对象
                ele.beams.Add(beam.Id);
            }

            //遍历所有柱
            FilteredElementCollector collumncollector = new FilteredElementCollector(doc);
            ICollection<Element> columns = collumncollector.OfCategory(BuiltInCategory.OST_StructuralColumns)
                .OfClass(typeof(Autodesk.Revit.DB.FamilyInstance))
                .ToElements();
            TaskDialog.Show("123", "柱的数量" + columns.Count());
            foreach (Element column in columns)
            {
                Parameter parameter = column.LookupParameter("底部标高");

                Element f = doc.GetElement(parameter.AsElementId());
                if (f == null)
                {
                    TaskDialog.Show("错误", "未能根据id找到标高对象    " + parameter.AsElementId());
                }
                Elevation ele = elevations.Find(item => item.name == f.Name);//在所有标高中查找该元素对应的标高对象
                ele.columns.Add(column.Id);
            }

            //遍历完成
            //柱梁墙板
            //开始排序
            //创建文件
            FileInfo file = new FileInfo(@"E:\流程顺序.txt");//创建文件
            StreamWriter sw = file.AppendText();//打开追加流
            sw.WriteLine("曾志昊");
               //释放资源,关闭文件
            sw.Dispose();
            int i = 0;
            for (; i < elevations.Count;i++)
            {
                sw = file.AppendText();
                Elevation ele = elevations.Find(item => item.no == i);
                if(ele == null)
                {
                    TaskDialog.Show("错误", "未找到elevation对象");
                }
                string str = "";
                //板
                foreach (ElementId floorId in ele.floors)
                {
                    Element floor = doc.GetElement(floorId);
                    str = floor.Id.ToString() + "  ";
                    sw.WriteLine("标高" + i + "板  " + floor.Name + "  " + floor.Id.ToString());
                }
                //柱
                foreach (ElementId columnId in ele.columns)
                {
                    Element column = doc.GetElement(columnId);
                    str = column.Id.ToString() + "  " ;
                    sw.WriteLine("标高" + i + "柱  " +column.Name + "  " + column.Id.ToString());
                }
                //梁
                foreach (ElementId beamId in ele.beams)
                {
                    Element beam = doc.GetElement(beamId);
                    str = beam.Id.ToString() + "  ";
                    sw.WriteLine("标高" + i + "梁  " + beam.Name + "  " + beam.Id.ToString());
                }
                //墙
                foreach (ElementId wallId in ele.walls)
                {
                    Element wall = doc.GetElement(wallId);
                    str = wall.Id.ToString() + "  ";
                    sw.WriteLine("标高" + i + "墙  " + wall.Name + "  " + wall.Id.ToString());
                }
                sw.Dispose();
            }
        }
    }
}


//Solid solid = obj as Solid;
//if(solid!=null)
//{
//    volume = solid.Volume;
//    area = solid.Faces.get_Item(0).Area;
//    TaskDialog.Show("test", volume.ToString());
//    addIntoListView0(item.Category.Name, item.Id + "", volume + "", area + "");
//    continue;
//}
//GeometryInstance geometryInstance = obj as GeometryInstance;
//if(geometryInstance != null)
//{
//
//    //二重遍历
//    Solid solid2 = obj as Solid;
//    if (solid2 != null)
//    {
//        volume = solid.Volume;
//        area = solid.Faces.get_Item(0).Area;
//        addIntoListView0(item.Category.Name, item.Id + "", volume + "", area + "");
//    }
//    GeometryInstance geometryInstance2 = obj as GeometryInstance;
//    if (geometryInstance != null)
//    {
//        TaskDialog.Show("test", "需要三重遍历！");
//    }
//}




//GeometryInstance instance = obj as GeometryInstance;
//if (instance == null)
//    continue;
//GeometryElement geometryElement = instance.GetInstanceGeometry();
//if (geometryElement == null)
//    continue;
//foreach (GeometryObject elem in geometryElement)
//{
//    Solid solid = elem as Solid;
//    if (solid == null || solid.Volume + "" == "0")
//        continue;
//    FaceArray faceArray = solid.Faces;
//    volume = solid.Volume;
//    volumes[top] = volume;
//    top++;
//    area = faceArray.get_Item(1).Area;
//    //foreach (Face face in faceArray)
//    //{
//    //    info += "Face" + i + " 的面积: " + face.Area.ToString() + "\n";
//    //    i++;
//    //}
//}
