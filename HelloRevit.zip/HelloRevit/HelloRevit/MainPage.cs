﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Form = System.Windows.Forms.Form;


namespace HelloRevit
{
    public partial class MainPage : Form
    {

        private Document doc;
        private UIDocument uidoc;
        public MainPage()
        {
            InitializeComponent();
        }
        public MainPage(UIDocument uidoc)
        {
            InitializeComponent();
            this.uidoc = uidoc;
            this.doc = uidoc.Document;
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(uidoc);
            form2.Show();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Process();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("E:\\Revit2016\\C#Project\\VideoSystem\\VideoSystem\\bin\\Debug\\VideoSystem.exe");
            //Player player = new Player();
            //player.Show();
        }
        private List<Elevation> elevations;
        private void Process()
        {
            //获得所有标高
            FilteredElementCollector collector = new FilteredElementCollector(uidoc.Document);
            ICollection<Element> levels = collector.OfClass(typeof(Level)).ToElements();
            elevations = new List<Elevation>();
            foreach (Element level in levels)
            {
                elevations.Add(new Elevation(level.Name, level.Id));
            }
            //TaskDialog.Show("标高", "已获得所有标高!");

            //遍历所有墙
            FilteredElementCollector wallcollector = new FilteredElementCollector(doc);
            ICollection<Element> walls = wallcollector.OfClass(typeof(Wall)).ToElements();
            foreach (Element wall in walls)
            {
                Parameter parameter = wall.LookupParameter("底部限制条件");
                Element f = doc.GetElement(parameter.AsElementId());
                Elevation ele = elevations.Find(item => item.name == f.Name);//在所有标高中查找该元素对应的标高对象
                ele.walls.Add(wall.Id);
            }
            //遍历所有板
            FilteredElementCollector floorcollector = new FilteredElementCollector(doc);
            ICollection<Element> floors = floorcollector.OfClass(typeof(Floor)).ToElements();
            foreach (Element floor in floors)
            {
                Parameter parameter = floor.LookupParameter("标高");
                Element f = doc.GetElement(parameter.AsElementId());
                Elevation ele = elevations.Find(item => item.name == f.Name);//在所有标高中查找该元素对应的标高对象
                //TaskDialog.Show("找到ele对象", ele.name + "   " + ele.no + "   ");
                ele.floors.Add(floor.Id);
               // TaskDialog.Show("count", "" + ele.floors.Count());
            }

            //遍历所有梁
            FilteredElementCollector beamcollector = new FilteredElementCollector(doc);
            ICollection<Element> beams = beamcollector.OfCategory(BuiltInCategory.OST_StructuralFraming).OfClass(typeof(FamilyInstance)).ToElements();
           

            foreach (Element beam in beams)
            {
                Parameter parameter = beam.LookupParameter("参照标高");
                Element f = doc.GetElement(parameter.AsElementId());
                if (f == null)
                {
                    TaskDialog.Show("错误", "未能根据id找到标高对象    " + parameter.AsElementId());
                }
                Elevation ele = elevations.Find(item => item.name == f.Name);//在所有标高中查找该元素对应的标高对象
                ele.beams.Add(beam.Id);
            }

            //遍历所有柱
            FilteredElementCollector collumncollector = new FilteredElementCollector(doc);
            ICollection<Element> columns = collumncollector.OfCategory(BuiltInCategory.OST_StructuralColumns)
                .OfClass(typeof(Autodesk.Revit.DB.FamilyInstance))
                .ToElements();
            foreach (Element column in columns)
            {
                Parameter parameter = column.LookupParameter("底部标高");

                Element f = doc.GetElement(parameter.AsElementId());
                if (f == null)
                {
                    TaskDialog.Show("错误", "未能根据id找到标高对象    " + parameter.AsElementId());
                }
                Elevation ele = elevations.Find(item => item.name == f.Name);//在所有标高中查找该元素对应的标高对象
                ele.columns.Add(column.Id);
            }

            //遍历完成
            //柱梁墙板
            //开始排序
            //创建文件
            FileInfo file = new FileInfo(@"E:\资料\智慧建造\新建文件夹\施工流程.txt");//创建文件
            StreamWriter sw = file.AppendText();//打开追加流
            //释放资源,关闭文件
            sw.Dispose();
            int i = 0;
            for (; i < elevations.Count; i++)
            {
                sw = file.AppendText();
                Elevation ele = elevations.Find(item => item.no == i);
                if (ele == null)
                {
                    TaskDialog.Show("错误", "未找到elevation对象");
                }
                string str = "";
                //板
                foreach (ElementId floorId in ele.floors)
                {
                    Element floor = doc.GetElement(floorId);
                    str = floor.Id.ToString() + "  ";
                    sw.WriteLine("标高" + i + "板  " + floor.Name + "  " + floor.Id.ToString());
                }
                //柱
                foreach (ElementId columnId in ele.columns)
                {
                    Element column = doc.GetElement(columnId);
                    str = column.Id.ToString() + "  ";
                    sw.WriteLine("标高" + i + "柱  " + column.Name + "  " + column.Id.ToString());
                }
                //梁
                foreach (ElementId beamId in ele.beams)
                {
                    Element beam = doc.GetElement(beamId);
                    str = beam.Id.ToString() + "  ";
                    sw.WriteLine("标高" + i + "梁  " + beam.Name + "  " + beam.Id.ToString());
                }
                //墙
                foreach (ElementId wallId in ele.walls)
                {
                    Element wall = doc.GetElement(wallId);
                    str = wall.Id.ToString() + "  ";
                    sw.WriteLine("标高" + i + "墙  " + wall.Name + "  " + wall.Id.ToString());
                }
                sw.Dispose();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void MainPage_Load(object sender, EventArgs e)
        {
            //button1.BackColor = System.Drawing.Color.Transparent;
            //button1.FlatStyle = FlatStyle.Flat;
            //button1.FlatAppearance.BorderSize = 0;
        }

    }
}
