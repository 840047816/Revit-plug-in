﻿using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;
namespace HelloRevit
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    class YesOrNoDialog
    {
        public Autodesk.Revit.UI.Result executehere(ExternalCommandData revit,
            ref string message, ElementSet elements)
        {
            //询问选择框
            try
            {
                TaskDialogResult result = TaskDialog.Show(
                    "Revit",
                    "yes or no",
                    TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No);
                if (result == TaskDialogResult.Yes)
                {
                    return Result.Succeeded;
                }
                else if (result == TaskDialogResult.No)
                {
                    message = "Failed here!!!!!!!!!!!!!!!!!!!!!!!!!!";
                    return Result.Failed;
                }
                else
                {
                    return Result.Cancelled;
                }
            }
            catch
            {
                message = "Unexpected exception here!!!!!!!!!!!!!!!!!!!!!!!";
                return Result.Failed;
            }

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }
      
}
