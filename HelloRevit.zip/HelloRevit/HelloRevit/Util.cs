﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloRevit
{
    public class Util
    {
        public double a1 = 0;
        public double a2 = 0;
        public double b1 = 0;
        public double b2 = 0;
        public double c1 = 0;
        public double c2 = 0;
        public double d1 = 0;
        public double d2 = 0;
    }
}
