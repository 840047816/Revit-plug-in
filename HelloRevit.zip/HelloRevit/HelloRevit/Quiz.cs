﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Form = System.Windows.Forms.Form;

namespace HelloRevit
{
    public partial class Quiz : Form
    {
        public Player player;
        public string path;
        private string question = "default question";
        private string selectionA = "default";
        private string selectionB = "default";
        private string selectionC = "default";
        private string selectionD = "default";
        private string answer = "";
        FileStream fs;
        StreamReader reader;
        private int right = 0;
        private int wrong = 0;
        private int total = 0;
        private int now = 0;

        public Quiz()
        {
            InitializeComponent();
        }

        public Quiz(Player player, string QuizPath)
        {
            InitializeComponent();
            this.player = player;
            this.path = QuizPath;
            fs = new FileStream(path, FileMode.OpenOrCreate);
            reader = new StreamReader(fs);
            string totalstr = reader.ReadLine();
            total = System.Convert.ToInt32(totalstr);
            label3.Text = "答对0道";
            label4.Text = "答错0道";
            refresh();
        }

        private string getSelectedItem()
        {
            if (radioButton1.Checked)
                return "A";
            else if (radioButton2.Checked)
                return "B";
            else if (radioButton3.Checked)
                return "C";
            else if (radioButton4.Checked)
                return "D";
            else
                return "N";
        }

        private int checkAnswer()
        {
            string selected = getSelectedItem();
            if (selected != "N")
            {
                if (selected == answer)
                    return 1;
                else
                    return 0;
            }
            else
            {
                TaskDialog.Show("请选择答案", "请选择答案");
                return -1;
            }
        }
        private void refresh()
        {
            if(now == total)
            {
                string score = "成绩不合格";
                if(right>=0.6*total)
                {
                    score = "成绩合格";
                }
                TaskDialog.Show("完成", "您已完成当前专题所有题目,一共"+total+"道题，您答对了"+right+"道,"+score);
                this.Close();
            }

            //文件输入流读取下一道题目以及选项答案
            question = reader.ReadLine();
            selectionA = reader.ReadLine();
            selectionB = reader.ReadLine();
            selectionC = reader.ReadLine();
            selectionD = reader.ReadLine();
            answer = reader.ReadLine();
            now++;
            label1.Text = question;
            radioButton1.Text = selectionA;
            radioButton2.Text = selectionB;
            radioButton3.Text = selectionC;
            radioButton4.Text = selectionD;
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (checkAnswer() == 1)
            {
                //答案正确
                right++;
                label3.Text = "答对" + right + "道";
                label2.Text = "";
                refresh();
            }
            else if (checkAnswer() == 0)
            {
                //答案错误
                wrong++;
                label4.Text = "答错" + wrong + "道";
                label2.Text = "上一题：答案错误！";
                refresh();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //释放资源,关闭文件
            reader.Dispose();
            this.Close();
        }

    }
}
