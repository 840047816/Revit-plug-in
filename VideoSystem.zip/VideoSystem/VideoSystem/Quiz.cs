﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VideoSystem
{
    public partial class Quiz : Form
    {
        public Player player;
        public string path;
        private string question = "default question";
        private string selectionA = "default";
        private string selectionB = "default";
        private string selectionC = "default";
        private string selectionD = "default";
        private string answer = "";
        public FileStream fs;
        StreamReader reader;
        private int right = 0;
        private int wrong = 0;
        private int total = 0;
        private int now = 0;
        private Player2 player2;
        public global glo;

        public Quiz()
        {
            InitializeComponent();
        }
        public Quiz(Player2 player2, string QuizPath,global  glo)
        {
            InitializeComponent();
            this.player2 = player2;
            this.path = QuizPath;

            fs = new FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read, FileShare.ReadWrite);
            reader = new StreamReader(fs);

            string totalstr = reader.ReadLine();
            total = System.Convert.ToInt32(totalstr);
            label3.Text = "答对0道";
            label4.Text = "答错0道";
            this.glo = glo;
            refresh();
        }

        public Quiz(Player player, string QuizPath)
        {
            InitializeComponent();
            this.player = player;
            this.path = QuizPath;
            fs = new FileStream(path, FileMode.OpenOrCreate);
            reader = new StreamReader(fs);
            string totalstr = reader.ReadLine();
            total = System.Convert.ToInt32(totalstr);
            label3.Text = "答对0道";
            label4.Text = "答错0道";
            refresh();
        }

        private string getSelectedItem()
        {
            if (radioButton1.Checked)
            {
                return "A";
            }
            else if (radioButton2.Checked)
            {
                return "B";
            }
            else if (radioButton3.Checked)
            {
                return "C";
            }
            else if (radioButton4.Checked)
            {
                return "D";
            } 
            else
                return "N";
        }

        private int checkAnswer()
        {
            string selected = getSelectedItem();
            if (selected != "N")
            {
                if (selected == answer)
                    return 1;
                else
                    return 0;
            }
            else
            {
                Warning warning = new Warning("请选择答案");
                warning.ShowDialog();
                return -1;
            }
        }
        private void refresh()
        {
            if (now == total)
            {
                string score = "成绩不合格";
                if (right >= 0.6 * total)
                {
                    score = "成绩合格";
                    glo.pass = true;
                }
                else
                {
                    glo.pass = false;
                }
                Warning warning = new Warning("您已完成当前专题所有题目,一共" + total + "道题，您答对了" + right + "道," + score);
                warning.ShowDialog();
                this.Close();
            }

            //文件输入流读取下一道题目以及选项答案
            question = reader.ReadLine();
            selectionA = reader.ReadLine();
            selectionB = reader.ReadLine();
            selectionC = reader.ReadLine();
            selectionD = reader.ReadLine();
            answer = reader.ReadLine();
            now++;
            label1.Text = question;
            radioButton1.Text = selectionA;
            radioButton2.Text = selectionB;
            radioButton3.Text = selectionC;
            radioButton4.Text = selectionD;

        }
        private RadioButton checkedButton;
        private void button1_Click(object sender, EventArgs e)
        {
            if (checkAnswer() == 1)
            {
                //答案正确
                right++;
                label3.Text = "答对" + right + "道";
                label2.Text = "";
                refresh();
               
            }
            else if (checkAnswer() == 0)
            {
                //答案错误
                wrong++;
                label4.Text = "答错" + wrong + "道";
                label2.Text = "上一题：答案错误！";
                refresh();
            }
            switch (getSelectedItem())
            {
                case "A":
                    radioButton1.Checked = false;
                    break;
                case "B":
                    radioButton2.Checked = false;
                    break;
                case "C":
                    radioButton3.Checked = false;
                    break;
                case "D":
                    radioButton4.Checked = false;
                    break;
                default:
                    break;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //释放资源,关闭文件
            if(right/total < 0.6)
            {
                glo.pass = false;
                Warning warning = new Warning("本次测试未合格，请重新观看视频并测试");
                warning.Show();
            }
            reader.Dispose();
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Quiz_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
