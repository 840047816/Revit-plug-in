﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VideoSystem
{
    public partial class MyPlayer : Form
    {
        public MyPlayer()
        {
            InitializeComponent();
            axWindowsMediaPlayer1.URL = "E:\\人人影视Pro\\摩登家庭第9季\\摩登家庭.Modern.Family.S09E01.中英字幕.WEB.720p-人人影视.mp4";
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }

        private void MyPlayer_Load(object sender, EventArgs e)
        {

        }
    }
}
