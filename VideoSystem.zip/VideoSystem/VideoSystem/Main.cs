﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VideoSystem
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Quiz quiz = new Quiz();
            //Player player = new Player(quiz,"E:\\人人影视Pro\\摩登家庭第9季\\摩登家庭.Modern.Family.S09E01.中英字幕.WEB.720p-人人影视.mp4");
            // player.ShowDialog();

            MyPlayer myPlayer = new MyPlayer();
            myPlayer.Show();

            //Player2 player2 = new Player2();
            //player2.ShowDialog();
            //quiz.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Player2 player2 = new Player2();
            player2.Show();
        }
    }
}
