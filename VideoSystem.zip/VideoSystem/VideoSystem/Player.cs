﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VideoSystem
{
    public partial class Player : Form
    {
        public Quiz quiz;
        public string path = "";

        public Player()
        {
            InitializeComponent();
        }
        public Player(Quiz quiz,string VideoPath)
        {
            InitializeComponent();
            this.quiz = quiz;
            this.path = VideoPath;

            //axWindowsMediaPlayer1.BeginInit();
            //this.Controls.Add(axWindowsMediaPlayer1);
            //axWindowsMediaPlayer1.EndInit();
            axWindowsMediaPlayer1.URL = path;
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }

        private void Player_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
