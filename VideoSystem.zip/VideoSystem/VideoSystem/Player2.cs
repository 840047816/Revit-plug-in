﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VideoSystem
{
    public partial class Player2 : Form 
    {
        private bool[] passed;
        private bool pass = true;
        private int selected = 5;
        public string path = "";
        public string quizpath = "E:\\资料\\智慧建造\\123.txt";
        private Quiz quiz;
        public bool isplaying = false;
        //private void play(string type)
        //{
        //    bool change = true;
        //    switch (type)
        //    {
        //        case "次梁装配":
        //            break;
        //        case "楼梯装配":
        //            break;
        //        case "楼板装配":
        //            break;
        //        case "柱装配":
        //            break;
        //        case "内外墙装配":
        //            break;
        //        case "总体流程":
        //            break;
        //        default:
        //            change = false;
        //            break;
        //    }
        //    if (change)
        //    {
        //        if (isplaying)
        //        {
        //            axWindowsMediaPlayer1.Ctlcontrols.stop();
        //            isplaying = false;
        //        }
        //        if(type != "总体流程")
        //        {
        //            path = "E:\\资料\\智慧建造\\视频\\" + type + ".mp4";
        //            quizpath = "E:\\资料\\智慧建造\\题目\\" + type + ".txt";
        //            axWindowsMediaPlayer1.URL = path;
        //            if (quiz != null)
        //            {
        //                if (!quiz.IsDisposed)
        //                {
        //                    quiz.fs.Close();
        //                    quiz.fs.Dispose();
        //                    quiz.Close();
        //                    quiz.Dispose();
        //                }
        //            }
        //            quiz = new Quiz(this, quizpath);

        //            //try
        //            //{
        //            axWindowsMediaPlayer1.Ctlcontrols.play();
        //            //}
        //            //catch (Exception e)
        //            //{
        //            //    Warning warning = new Warning(e.ToString());
        //            //    warning.Show();
        //            //}
        //            isplaying = true;
        //            quiz.Show();
        //        }
               
        //    }
        //}
        private void onlyPlay(string type)
        {
            if (isplaying)
            {
                axWindowsMediaPlayer1.Ctlcontrols.stop();
                isplaying = false;
            }
            path = "E:\\资料\\智慧建造\\视频\\" + type + ".mp4";
            axWindowsMediaPlayer1.URL = path;
            axWindowsMediaPlayer1.Ctlcontrols.play();
            isplaying = true;
        }
        public Player2()
        {
            InitializeComponent();
            passed = new bool[6];
            passed[0] = false;
            passed[1] = false;
            passed[2] = false;
            passed[3] = false;
            passed[4] = false;
            passed[5] = true;

            //quiz = new Quiz(this, quizpath);
            //quiz.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if(passed[selected] || selected == 0)
            {
                button7.Show();
                quizpath = "E:\\资料\\智慧建造\\题目\\" + button1.Text + ".txt";
                selected = 0;
                onlyPlay(button1.Text);
            }
            else
            {
                Warning warning = new Warning("请完成上一课程测试");
                warning.Show();
            }
        }

        private void Player2_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = Image.FromFile("E:\\资料\\智慧建造\\图片\\图片2.png");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (passed[selected]||selected == 1)
            {
                button7.Show();
                quizpath = "E:\\资料\\智慧建造\\题目\\" + button2.Text + ".txt";
                selected = 1;
                onlyPlay(button2.Text);
            }
            else
            {
                Warning warning = new Warning("请完成上一课程测试");
                warning.Show();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if(passed[selected] || selected == 2)
            {
                button7.Show();
                quizpath = "E:\\资料\\智慧建造\\题目\\" + button3.Text + ".txt";
                selected = 2;

                onlyPlay(button3.Text);
            }
            else
            {
                Warning warning = new Warning("请完成上一课程测试");
                warning.Show();
            }

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if(passed[selected] || selected == 3)
            {
                button7.Show();
                quizpath = "E:\\资料\\智慧建造\\题目\\" + button4.Text + ".txt";
                selected = 3;

                onlyPlay(button4.Text);
            }
            else
            {
                Warning warning = new Warning("请完成上一课程测试");
                warning.Show();
            }
            
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if(passed[selected] || selected == 4)
            {
                button7.Show();
                quizpath = "E:\\资料\\智慧建造\\题目\\" + button5.Text + ".txt";
                selected = 4;

                onlyPlay(button5.Text);
            }
            else
            {
                Warning warning = new Warning("请完成上一课程测试");
                warning.Show();
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {

            //play(button6.Text);
            button7.Hide();
            quizpath = "E:\\资料\\智慧建造\\题目\\" + button6.Text + ".txt";
            onlyPlay(button6.Text);
        }
        public global glo;
        private void button7_Click(object sender, EventArgs e)
        {
            if (quiz != null)
            {
                if (!quiz.IsDisposed)
                {
                    quiz.fs.Close();
                    quiz.fs.Dispose();
                    quiz.Close();
                    quiz.Dispose();
                }
            }
            glo = new global();
            quiz = new Quiz(this, quizpath,glo);
            quiz.ShowDialog();
            this.passed[selected] = glo.pass;
        }
    }
}
